<?php
/**
 * Template to displaying single portfolio
 * This template be registered in this plugin
 *
 * @since 1.0
 */

get_header();

$style = get_theme_mod( 'penci_portfolio_cat_layout' );
if ( ! isset( $style ) || empty( $style ) ):  $style = 'gallery-grid'; endif;
?>

<div class="container <?php if ( get_theme_mod( 'penci_portfolio_cat_enable_sidebar' ) ) : ?>penci_sidebar<?php endif; ?>">
	<div id="main">
		<div class="post-header">
			<h1><span><?php single_cat_title(); ?></span></h1>
		</div>
		<?php if( have_posts() ): ?>
			<div class="penci-portfolio-wrap <?php echo $style; ?> column-<?php if ( get_theme_mod( 'penci_portfolio_cat_enable_sidebar' ) ) { echo '2'; } else { echo '3'; } ?>">
				<div class="inner-portfolio-posts">
					<?php while ( have_posts() ): the_post(); ?>
						<article class="portfolio-item" id="portfolio-<?php the_ID(); ?>">
							<div class="inner-item-portfolio">
								<div class="info-portfolio">
									<div class="portfolio-overlay-content">
										<div class="portfolio-short">
											<?php if ( $style == 'gallery-grid' ): ?>
												<h3 class="portfolio-title">
													<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
												</h3>
											<?php endif; ?>
											<div class="portfolio-buttons">
												<?php echo penci_getPostLikeLink( get_the_ID() ); ?>
												<?php $url_thumbnail = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ); if( ! $url_thumbnail ): $url_thumbnail = PENCI_PORTFOLIO_URL . '/images/no-thumbnail.jpg'; endif; ?>
												<a href="<?php echo $url_thumbnail; ?>" class="portfolio-expand-image"><i class="fa fa-expand"></i></a>
												<a href="<?php the_permalink(); ?>"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<?php /* Thumbnail */
									if ( has_post_thumbnail() ) {
										the_post_thumbnail( 'thumb' );
									}
									else {
										echo '<img src="' . PENCI_PORTFOLIO_URL . '/images/no-thumbnail.jpg" alt="' . __( "No Thumbnail", "pencidesign" ) . '" />';
									}
									?>
									<div class="portfolio-overlay-background"></div>
								</div>
							</div>
							<?php if ( $style == 'text-grid' ): ?>
								<div class="text-grid-info">
								<h3 class="title-gallery-grid">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<?php
								if ( ! get_theme_mod( 'penci_portfolio_text_grid_cat' ) ) :
									/* Get list term of this portfolio */
									$get_terms = wp_get_post_terms( $post->ID, 'portfolio-category' );
									if ( ! empty( $get_terms ) ):
										?>
										<div class="text-grid-cat">
											<?php
											$list_cats = array();
											foreach ( $get_terms as $term ) {
												$list_cats[] = '<a href="' . get_term_link( $term, 'portfolio-category' ) . '">' . $term->name . '</a>';
											}
											$list_cats = implode( ', ', $list_cats );
											echo $list_cats;
											?>
										</div>
										</div>
									<?php endif; endif; ?>
							<?php endif; ?>
						</article>
					<?php endwhile; ?>
				</div>
			</div>
			<?php pencidesign_pagination(); ?>
		<?php endif; wp_reset_query(); ?>
	</div>

<?php if ( get_theme_mod( 'penci_portfolio_cat_enable_sidebar' ) ) : ?><?php get_sidebar(); ?><?php endif; ?>

<?php get_footer(); ?>