<?php
/**
 * Template to displaying single portfolio
 * This template be registered in this plugin
 *
 * @since 1.0
 */

get_header();

$description_text = get_theme_mod( 'penci_portfolio_description_text' );
if( empty( $description_text ) ): $description_text = __( 'Description', 'pencidesign' ); endif;
?>

<div class="container <?php if ( get_theme_mod( 'penci_portfolio_single_enable_sidebar' ) ) : ?>penci_sidebar<?php endif; ?>">
	<div id="main">
		<?php /* The loop */
		while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="post-header">
					<h1><span><?php the_title(); ?></span></h1>
				</div>
				<div class="post-entry<?php if ( get_theme_mod( 'penci_portfolio_share_box' ) ): echo ' page-has-margin'; endif; ?>">
					<div class="portfolio-page-content">
						<div class="portfolio-left">
							<?php /* Thumbnail */
							if ( has_post_thumbnail() ) {
								the_post_thumbnail( 'full' );
							}
							else {
								echo '<img src="' . PENCI_PORTFOLIO_URL . '/images/no-thumbnail.jpg" alt="' . __( "No Thumbnail", "pencidesign" ) . '" />';
							}
							?>
						</div>
						<div class="portfolio-right">
							<div class="detail-portfolio">
								<div class="pattern-grey"></div>
								<div class="inner-detail">
									<h2 class="title-description"><?php echo $description_text; ?></h2>
									<?php the_content(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php if ( ! get_theme_mod( 'penci_portfolio_share_box' ) ) : ?>
					<div class="tags-share-box hide-tags page-share">
						<div class="pattern-grey"></div>
						<div class="post-share">
							<span class="share-title"><?php _e( 'Share:', 'pencidesign' ); ?></span>
							<div class="list-posts-share">
								<a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><span class="share-box"><i class="fa fa-facebook"></i></span></a>
								<a target="_blank" href="https://twitter.com/home?status=Check%20out%20this%20article:%20<?php the_title(); ?>%20-%20<?php the_permalink(); ?>"><span class="share-box"><i class="fa fa-twitter"></i></span></a>
								<a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><span class="share-box"><i class="fa fa-google-plus"></i></span></a>
								<?php $pinterest_image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ); ?>
								<a target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php echo $pinterest_image; ?>&description=<?php the_title(); ?>"><span class="share-box"><i class="fa fa-pinterest"></i></span></a>
							</div>
						</div>
					</div>
				<?php endif; ?>
			</article>
		<?php endwhile; ?>
	</div>

	<?php if ( get_theme_mod( 'penci_portfolio_single_enable_sidebar' ) ) : ?><?php get_sidebar(); ?><?php endif; ?>

<?php get_footer(); ?>